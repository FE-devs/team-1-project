<form method="post" action="javascript:void(0)" id="updatewithdrawalinfo">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <fieldset>
        <legend>Bank Account</legend>
        <div class="form-row">
            <div class="form-group col-md-6">
                <h5 class="text-<?php echo e($text); ?>">Bank Name</h5>
                <input type="text" name="bank_name" value="<?php echo e(Auth::user()->bank_name); ?>"  class="form-control text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Enter bank name">
            </div>
            <div class="form-group col-md-6">
                <h5 class="text-<?php echo e($text); ?>">Account Name</h5>
                <input type="text" name="account_name" value="<?php echo e(Auth::user()->account_name); ?>"  class="form-control  text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Enter Account name">
            </div>
            <div class="form-group col-md-6">
                <h5 class="text-<?php echo e($text); ?>">Account Number</h5>
                <input type="text" name="account_no" value="<?php echo e(Auth::user()->account_number); ?>"  class="form-control text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Enter Account Number">
            </div>
            <div class="form-group col-md-6">
                <h5 class="text-<?php echo e($text); ?>">Swift Code</h5>
                <input type="text" name="swiftcode" value="<?php echo e(Auth::user()->swift_code); ?>"  class="form-control text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Enter Swift Code">
            </div>
        </div>
    </fieldset>
    <fieldset class="mt-2">
        <legend>Cryptocurrency</legend>
        <div class="form-row">
            <div class="form-group col-md-6">
                <h5 class="text-<?php echo e($text); ?>">Bitcoin</h5>
                <input type="text" name="btc_address" value="<?php echo e(Auth::user()->btc_address); ?>"  class="form-control text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Enter Bitcoin Address">
                <small class="text-<?php echo e($text); ?>">Enter your Bitcoin Address that will be used to withdraw your funds</small>
            </div>
            <div class="form-group col-md-6">
                <h5 class="text-<?php echo e($text); ?>">Ethereum</h5>
                <input type="text" name="eth_address" value="<?php echo e(Auth::user()->eth_address); ?>"  class="form-control text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Enter Etherium Address">
                <small class="text-<?php echo e($text); ?>">Enter your Ethereum Address that will be used to withdraw your funds</small>
            </div>
            <div class="form-group col-md-6">
                <h5 class="text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>">Litecoin</h5>
                <input type="text" name="ltc_address" value="<?php echo e(Auth::user()->ltc_address); ?>"  class="form-control text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Enter Litcoin Address">
                <small class="text-<?php echo e($text); ?>">Enter your Litecoin Address that will be used to withdraw your funds</small>
            </div>
        </div>
    </fieldset>
    <button type="submit" class="px-5 btn btn-primary">Save</button>
</form>


<script>
    
    $('#updatewithdrawalinfo').on('submit', function() {
       // alert('love');
        $.ajax({
            url: "<?php echo e(route('updateacount')); ?>",
            type: 'POST',
            data: $('#updatewithdrawalinfo').serialize(),
            success: function(response) {
                if (response.status === 200) {
                    $.notify({
                        // options
                        icon: 'flaticon-alarm-1',
                        title: 'Success',
                        message: response.success,
                    },{
                        // settings
                        type: 'success',
                        allow_dismiss: true,
                        newest_on_top: false,
                        showProgressbar: true,
                        placement: {
                            from: "top",
                            align: "right"
                        },
                        offset: 20,
                        spacing: 10,
                        z_index: 1031,
                        delay: 5000,
                        timer: 1000,
                        url_target: '_blank',
                        mouse_over: null,
                        animate: {
                            enter: 'animated fadeInDown',
                            exit: 'animated fadeOutUp'
                        },
    
                    });
                } else {
                   
                }
            },
            error: function(data) {
                console.log(data);
            },
    
        });
    });
</script><?php /**PATH /home/bryngrgz/oct2021.brynamics.xyz/resources/views/profile/update-withdrawal-method.blade.php ENDPATH**/ ?>