<?php echo e($slot); ?>

<?php /**PATH /home/tmoney/staff.jdhealthcareservices.com/yyy/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>