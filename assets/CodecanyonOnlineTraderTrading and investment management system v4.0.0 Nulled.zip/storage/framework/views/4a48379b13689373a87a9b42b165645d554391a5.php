[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/bryngrgz/oct2021.brynamics.xyz/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>