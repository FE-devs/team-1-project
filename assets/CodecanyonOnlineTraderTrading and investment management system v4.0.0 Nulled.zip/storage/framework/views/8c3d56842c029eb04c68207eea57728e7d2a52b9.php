<?php
	if (Auth::user()->dashboard_style == "light") {
		$bgmenu="blue";
    $bg="light";
    $text = "dark";
} else {
    $bgmenu="dark";
    $bg="dark";
    $text = "light";

}
?>

    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('user.topmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-panel bg-<?php echo e($bg); ?>">
			<div class="content bg-<?php echo e($bg); ?>">
				<div class="page-inner">
					<div class="mt-2 mb-4">
					<h1 class="title1 text-<?php echo e($text); ?>">Request for Withdrawal</h1>
					</div>
					<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.danger-alert','data' => []]); ?>
<?php $component->withName('danger-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
					<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.success-alert','data' => []]); ?>
<?php $component->withName('success-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
					<div class="mb-5 row">
					<?php $__currentLoopData = $wmethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-lg-4">
						<div class="p-3 rounded card bg-<?php echo e($bg); ?>">
							<div class="card-body border-danger">
								<h2 class="card-title mb-3 text-<?php echo e($text); ?>"> <?php echo e($method->name); ?></h2>
								<h4 class="text-<?php echo e($text); ?>">Minimum amount: <strong style="float:right;"> <?php echo e($settings->currency); ?><?php echo e($method->minimum); ?></strong></h4><br>
								
								<h4 class="text-<?php echo e($text); ?>">Maximum amount:<strong style="float:right;"> <?php echo e($settings->currency); ?><?php echo e($method->maximum); ?></strong></h4><br>
								
								<h4 class="text-<?php echo e($text); ?>">Charge Type:<strong style="float:right;"><?php echo e($method->charges_type); ?></strong></h4><br>
								
								<h4 class="text-<?php echo e($text); ?>">Charges Amount: 
									<strong style="float:right;"> 
										<?php if($method->charges_type == "percentage"): ?>
											<?php echo e($method->charges_amount); ?>%
										<?php else: ?>
											<?php echo e($settings->currency); ?><?php echo e($method->charges_amount); ?>

										<?php endif; ?>
									</strong>
								</h4><br>
								
								<h4 class="text-<?php echo e($text); ?>">Duration:<strong style="float:right;"> <?php echo e($method->duration); ?></strong></h4><br>
								<div class="text-center">
									<?php if($settings->enable_with == "false"): ?>
										<button class="btn btn-primary" data-toggle="modal" data-target="#withdrawdisabled"><i class="fa fa-plus"></i> Request withdrawal</button>
									<?php else: ?>
										<form action='<?php echo e(route('withdrawamount')); ?>' method="POST">
											<?php echo csrf_field(); ?>
											<div class="form-group">
												<input type="hidden" value="<?php echo e($method->name); ?>" name="method">
												<button class="btn btn-primary" type='submit'><i class="fa fa-plus"></i> Request withdrawal</button>
											</div>
											
										</form>
										
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<!-- Withdrawal Modal -->
					<div id="withdrawdisabled" class="modal fade" role="dialog">
						<div class="modal-dialog">
						  <!-- Modal content-->
						  <div class="modal-content">
							<div class="modal-header bg-<?php echo e($bg); ?>">
							<h4 class="modal-title text-<?php echo e($text); ?>">Withdrawal Status</h4>
							  <button type="button" class="close text-<?php echo e($text); ?>" data-dismiss="modal">&times;</button>
							</div>
							<div class="modal-body bg-<?php echo e($bg); ?>">
								<h4 class="text-<?php echo e($text); ?>" >Withdrawal is Disabled at the moment, Please check back later</h4>  
							</div>
						  </div>
						</div>
					  </div>
					  <!-- /Withdrawals Modal -->
				</div>
			</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\VICTORY.E\Documents\Brynamics\New Version\Online-Trade-2021\resources\views/user/withdrawals.blade.php ENDPATH**/ ?>