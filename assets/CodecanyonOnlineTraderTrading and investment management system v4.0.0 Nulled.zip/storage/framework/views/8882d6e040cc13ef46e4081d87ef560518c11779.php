<?php
	if (Auth::user()->dashboard_style == "light") {
		$bgmenu="blue";
    $bg="light";
    $text = "dark";
} else {
    $bgmenu="dark";
    $bg="dark";
    $text = "light";

}
?>

    <?php $__env->startSection('content'); ?>
        <?php echo $__env->make('user.topmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-panel bg-<?php echo e($bg); ?>">
			<div class="content bg-<?php echo e($bg); ?>">
				<div class="page-inner">
					<div class="mt-2 mb-4">
					    <h1 class="title1 d-inline text-<?php echo e($text); ?>">Request for Withdrawal</h1>
                        <div class="d-inline">
                            <div class="float-right btn-group">
                                <?php if(Auth::user()->sendotpemail == 'Yes'): ?>
                                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('getotp')); ?>"> <i class="fa fa-envelope"></i> Request OTP</a>          
                                <?php endif; ?>
                               
                            </div>
                        </div>
                        <?php if(session('status')): ?>
                        <script type="text/javascript">
                            swal({
                                title: "Error!",
                                text: "<?php echo e(session('status')); ?>",
                                icon: "error",
                                buttons: {
                                    confirm: {
                                        text: "Okay",
                                        value: true,
                                        visible: true,
                                        className: "btn btn-danger",
                                        closeModal: true
                                    }
                                }
                            });
                        </script>
                        <?php echo e(session()->forget('status')); ?>

                        <?php endif; ?>
					</div>
					<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.danger-alert','data' => []]); ?>
<?php $component->withName('danger-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
					<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.success-alert','data' => []]); ?>
<?php $component->withName('success-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    
					<div class="mb-5 row">
                        <div class="col-lg-8 offset-md-2">
                            <div class="p-md-4 p-2 rounded card bg-<?php echo e($bg); ?>">
                                <div class="card-body">
                                <div class="mb-3 alert alert-success">
                                    <h4 class="text-dark">Your Payment Method is <strong><?php echo e($payment_mode); ?></strong></h4>
                                </div>
                                    <form action="<?php echo e(route('completewithdrawal')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <h5 class="text-<?php echo e($text); ?>">Enter Amount to withdraw</h5>
                                            <input class="form-control text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Enter Amount" type="number" name="amount" required>
                                        </div>
                                        <input value="<?php echo e($payment_mode); ?>"  type="hidden" name="method">

                                        <?php if(Auth::user()->sendotpemail == 'Yes'): ?>
                                            <div class="form-group">
                                                <h5 class="text-<?php echo e($text); ?>">Enter OTP</h5>
                                                <input class="form-control text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Enter Code" type="text" name="otpcode" required>
                                                <small class="text-<?php echo e($text); ?>">OTP will be sent to your email when you request</small>
                                            </div> 
                                        <?php endif; ?>
                                        <?php if(!$default): ?>
                                            <?php if($methodtype == 'crypto'): ?>
                                                <div class="form-group">
                                                    <h5 class="text-<?php echo e($text); ?>">Enter <?php echo e($payment_mode); ?> Address </h5>
                                                    <input class="form-control text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" placeholder="Enter <?php echo e($payment_mode); ?> Address" type="text" name="details" required>
                                                    <small class="text-<?php echo e($text); ?>"><?php echo e($payment_mode); ?> is not a default withdrawal option in your account, please enter the correct wallet address to recieve your funds.</small>
                                                </div>  
                                            <?php else: ?>
                                               <div class="form-group">
                                                    <h5 class="text-<?php echo e($text); ?>">Enter <?php echo e($payment_mode); ?> Details </h5>
                                                    <textarea class="form-control text-<?php echo e($text); ?> bg-<?php echo e($bg); ?>" row="4" name="details" placeholder="BankName: Name, Account Number: Number, Account name: Name, Swift Code: Code" required>
                                                    
                                                    </textarea>
                                                    <small class="text-<?php echo e($text); ?>"><?php echo e($payment_mode); ?> is not a default withdrawal option in your account, please enter the correct bank details seperated by comma to recieve your funds.</small> <br/>
                                                    <span class="text-danger">BankName: Name, Account Number: Number, Account name: Name, Swift Code: Code</span>
                                                </div>  
                                            <?php endif; ?>
                                            
                                        <?php endif; ?>
                                        <div class="form-group">
                                            <button class="btn btn-primary" type='submit'>Complete Request</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
					</div>
				</div>
			</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bryngrgz/oct2021.brynamics.xyz/resources/views/user/withdraw.blade.php ENDPATH**/ ?>